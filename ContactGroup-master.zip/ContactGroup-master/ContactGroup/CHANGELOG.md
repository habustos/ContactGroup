# Change Log

## [1.0.1] 2020-01-18
### Improvements

- Bump UI: [Jinja Gradient Able](https://github.com/app-generator/jinja-gradient-able/releases) v1.0.1
- UI: [Gradient Able](https://github.com/codedthemes/Gradient-Able-free-bootstrap-admin-template) 2021-01-01 snapshot
- Codebase: [Django Dashboard](https://github.com/app-generator/boilerplate-code-django-dashboard/releases) v1.0.4

## [1.0.0] 2020-02-07
### Initial Release
