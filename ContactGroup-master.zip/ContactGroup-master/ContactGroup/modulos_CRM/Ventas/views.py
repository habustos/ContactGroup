from django.views.generic import ListView, CreateView, UpdateView
from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from .models import *
from .forms import *
import urllib.request, json

from django.shortcuts import render


def Venta_inicio(request):
    Doc_Cliente = request.POST.get('numero_documento')
    if request.method=="POST":
        Doc_Cliente = Cliente.objects.filter(numero_documento=Doc_Cliente)
        #Doc_Cliente = Categorias_planes.objects.filter(numero_documento=Doc_Cliente)

    return render(request, 'Ventas/Busqueda_Cedula.html',{
            'Doc_Cliente': Doc_Cliente,
        }
                      )



class Ventas_Form(CreateView):
    model = Cliente
    form_class = Venta_Form
    success_url = reverse_lazy('home')


"""
def Ventas_form(request):
    #client = models.Client.objects.get(pk = client_id)
    #notes = client.note_set.all()
    if request.method == 'POST':
        form = Venta_Form(request.POST)
        if form.is_valid():
            form.save(True)
            request.user.message_set.create(message = "Note is successfully added.")
            return render(request, "home")
    else:
        form = Venta_Form()
    return render(request, "home")







    class Ventas_form(CreateView):
    #model = Cliente
    model = Cliente
    form_class = Venta_Form
    success_url = reverse_lazy('home')

    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.user = self.request.user
        self.object.save()
        return super(Ventas_form, self).form_valid(form)
"""

class PersonUpdateView(UpdateView):
    #model = Cliente
    form_class = Venta_Form
    success_url = reverse_lazy('home')

"""
def load_cities(request):
    depto_id = request.GET.get('depto')
    tipo_plan_id = request.GET.get('tipo_plan')
    cities = Ciudad.objects.filter(depto_id=depto_id).order_by('nombre')
    planes = Plan.objects.filter(tipo_plan_id=tipo_plan_id).order_by('nombre')

    return render(request, 'Ventas/city_dropdown_list_options.html',
                  {'cities': cities,
                   'planes':planes,
                   })





    else:
        return render(request, 'index.html',
                      {
                          'Doc_Cliente': Doc_Cliente
                      }
                      )


    if request.method=="POST":
        cur.execute("DELETE FROM app_temporal_detalles;")
        cur.execute("UPDATE SQLITE_SEQUENCE SET SEQ=0 WHERE NAME='app_temporal_detalles';")
        cur.execute("DELETE FROM app_temporal_tablas;")
        cur.execute("UPDATE SQLITE_SEQUENCE SET SEQ=0 WHERE NAME='app_temporal_tablas';")

        return render(request, 'index_asesor.html',
                      {
            #####===Backoffice_Fija===#####
            'Backoffice_Fija_Template':Backoffice_Fija_Template,
            'Consulta_GVP': Consulta_GVP,
            'Regularizacion_de_averias_TimeOut': Regularizacion_de_averias_TimeOut,
            'Regularizacion_de_averias_no_agendador':Regularizacion_de_averias_no_agendador,
            'Reintentos_fallidas_de_SOM':Reintentos_fallidas_de_SOM,

            #####===Backoffice_Movil===#####
            'Backoffice_Movil_Template':Backoffice_Movil_Template,
            'Consulta_HLR': Consulta_HLR,
            'Depuracion_XML':Depuracion_XML,

            #####===N1_Fija_Template===#####
            'N1_Fija_Template':N1_Fija_Template,

            #####===N1_Movil_Template===#####
            'N1_Movil_Template':N1_Movil_Template,
            'Cierre_Masivo_Decreto_464': Cierre_Masivo_Decreto_464,

            #####Fechas#####
            'Desde':Desde,
            'Hasta':Hasta
                      }
                      )
        else:
        #bot = Backoffice_Fija.objects.values('bot').order_by('bot').distinct()
        #promedio = Backoffice_Fija.objects.aggregate(average__Transcurrido=Avg('Transcurrido'))
        #Resultados = Backoffice_Fija.objects.all()
        #promedio['average__Transcurrido']
            return render(request, 'index.html',{
            #"bot":bot,
            #"promedio":promedio,
            #"Resultados":Resultados
        }
                      )

"""