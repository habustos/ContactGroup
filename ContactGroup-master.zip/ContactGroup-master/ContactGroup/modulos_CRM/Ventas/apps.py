from django.apps import AppConfig


class VentasConfig(AppConfig):
    name = 'Ventas'
