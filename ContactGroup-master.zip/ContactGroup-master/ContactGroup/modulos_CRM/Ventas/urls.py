from django.urls import include, path
from django.conf.urls import  url
from django.contrib.auth.decorators import login_required



from . import views

urlpatterns = [
    url(r'^chaining/', include('smart_selects.urls')),
    #url(r'^add/$', views.Cliente, name='modele_new'),
    #path('C_add/', views.Ventas_form.as_view(template_name="Ventas/cliente_form.html"), name='cliente_add'),
    path('C_add/', login_required(views.Ventas_Form.as_view(template_name="Ventas/cliente_form.html")), name='cliente_add'),
    #url('C_add/', views.Ventas_form, name='cliente_add'),
    #path('C_add/', views.Ventas_Form, name='cliente_nuevo'),
    #url(r'^Backoffice_Fija_xlsx/', login_required(views.Backoffice_Fija_xlsx.as_view()), name="Backoffice_Fija_xlsx"),

    path('C_search/', views.Venta_inicio, name='cliente_search'),
]