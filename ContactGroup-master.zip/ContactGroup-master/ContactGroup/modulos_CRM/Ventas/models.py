from django.db import models
from django.conf import settings
from .validators import valid_extension
import os
from smart_selects.db_fields import ChainedForeignKey,GroupedForeignKey

class Depto(models.Model):
    departamento = models.CharField(max_length=30)

    def __str__(self):
        return self.departamento


class Municipio(models.Model):
    municipio = models.CharField(max_length=30)
    departamento = models.ForeignKey(Depto, on_delete=models.CASCADE)

    def __str__(self):
        return self.municipio


class Categoria_Plan(models.Model):
    categoria = models.CharField(max_length=255)

    def __str__(self):
        return "%s" % self.categoria


class Tipo_Plan(models.Model):
    categoria = models.ForeignKey(Categoria_Plan, on_delete=models.CASCADE)
    tipo_plan = models.CharField(max_length=255)

    def __str__(self):
        return "%s" % self.tipo_plan


class Plan(models.Model):
    tipo_plan = models.ForeignKey(Tipo_Plan, on_delete=models.CASCADE)
    plan = models.CharField(max_length=255)

    def __str__(self):
        return "%s" % self.plan



def generate_path(instance, filename):
    folder = "Cliente_" + str(instance.numero_documento)
    return os.path.join("archivos", folder, filename)


class Cliente(models.Model):
    Fecha_Venta = models.DateTimeField(auto_now_add=False, auto_now=True)
    nombre1 = models.CharField(max_length=100)
    nombre2 = models.CharField(max_length=100)
    nombres = models.CharField(max_length=200)
    apellidos = models.CharField(max_length=100)
    tipo_documento = models.CharField(max_length=100)
    numero_documento = models.BigIntegerField()
    fecha_documento = models.DateField(null=True, blank=True)
    fecha_nacimiento = models.DateField(null=True, blank=True)
    departamento = models.ForeignKey(Depto, on_delete=models.CASCADE)
    municipio = ChainedForeignKey(
        Municipio,
        chained_field="departamento",
        chained_model_field="departamento",
        show_all=False,
        auto_choose=True
    )
    barrio = models.CharField(max_length=300)
    direccion = models.TextField(null=True, blank=True)
    email = models.EmailField()
    telefono_mig = models.BigIntegerField()
    telefono_2 = models.BigIntegerField()
    categoria = models.ForeignKey(Categoria_Plan, on_delete=models.CASCADE)
    tipo_plan = ChainedForeignKey(
        "Tipo_Plan",
        chained_field="categoria",
        chained_model_field="categoria",
        show_all=False,
        auto_choose=True,
    )
    plan = ChainedForeignKey(
        "Plan",
        chained_field="tipo_plan",
        chained_model_field="tipo_plan",
        show_all=False,
        auto_choose=True,
    )
    v_total_plan = models.BigIntegerField()
    observaciones = models.TextField()
    #archivo1 = models.FileField(upload_to="archivos/", null=True, blank=True)
    adjunto1 = models.FileField(upload_to=generate_path,validators=[valid_extension])
    adjunto2 = models.FileField(blank=True, null=True, upload_to=generate_path,validators=[valid_extension])
    adjunto3 = models.FileField(blank=True, null=True, upload_to=generate_path,validators=[valid_extension])
    asesor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='asesor')

    def __str__(self):
        return self.nombres

    def clean(self):
        self.nombre1 = self.nombre1.upper()
        self.nombre2 = self.nombre2.upper()
        self.apellidos = self.apellidos.upper()
        self.barrio = self.barrio.upper()
        self.direccion = self.direccion.upper()

    def save(self, *args, **kw):
        self.nombres = '{0} {1}'.format(self.nombre1.upper(),self.nombre2.upper())
        super(Cliente, self).save(*args,**kw)




class Datos_Entrega(models.Model):
    #nombre = models.ForeignKey(Cliente, on_delete=models.SET_NULL, null=True)
    departamento = models.ForeignKey(Depto, on_delete=models.CASCADE)
    municipio = ChainedForeignKey(
        Municipio,
        chained_field="departamento",
        chained_model_field="departamento",
        show_all=False,
        auto_choose=True
    )
    barrio = models.CharField(max_length=300)
    direccion = models.TextField(null=True, blank=True)
    asesor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    observaciones = models.TextField()



"""
result = MyModel.objects.annotate(
diff=F(int_1)+F(int_2)
).filter(diff__gte=5)


    asesor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        to_field='username',
        on_delete=models.CASCADE,
        editable=False
    )

"""