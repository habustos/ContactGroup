from django import forms
from .models import *



class Venta_Form(forms.ModelForm):
    class Meta:
        model = Cliente
        Tipo_Doc = [("CC", "CEDULA DE CIUDADANIA"), ("CE", "CEDULA DE EXTRANJERIA"), ("PA", "PASAPORTE")]
        Tipo_Doc = forms.ChoiceField(choices=Tipo_Doc)
        fields = ('nombre1',
                  'nombre2',
                  'apellidos',
                  'tipo_documento',
                  'numero_documento',
                  'fecha_documento',
                  'fecha_nacimiento',
                  'departamento',
                  'municipio',
                  'barrio',
                  'direccion',
                  'email',
                  'telefono_mig',
                  'telefono_2',
                  'categoria',
                  'tipo_plan',
                  'plan',
                  'v_total_plan',
                  'observaciones',
                  'adjunto1',
                  'adjunto2',
                  'adjunto3')

        labels = {'nombre1':'Primer nombre',
                  'nombre2': 'Segundo nombre',
                  'apellidos':'Apellidos',
                  'tipo_documento':'Tipo de documento',
                  'numero_documento':'Numero de documento',
                  'fecha_documento':'Fecha de expedición',
                  'fecha_nacimiento':'Fecha de nacimiento',
                  'departamento':'Departamento',
                  'municipio':'Municipio',
                  'barrio':'Barrio',
                  'direccion':'Direccion',
                  'email':'Correo electronico',
                  'telefono_mig':'Linea a migrar',
                  'telefono_2':'Linea secundaria',
                  #'categoria':'Categoría de servicio',
                  'tipo_plan':'Tipo de plan',
                  'plan':'Plan',
                  'v_total_plan':'Valor total',
                  'observaciones':'Observaciones del cliente',
                  'adjunto1':'Cedula',
                  'adjunto2': 'RUT',
                  'adjunto3': 'Otro',
        }
        widgets = {
            'fecha_documento': forms.DateInput(format=('%d-%m-%Y'), attrs={'id':'Fecha_Documento',
                #'class':'form-control'
                                                                                   'type':'date'}),
            'fecha_nacimiento': forms.DateInput(format=('%d-%m-%Y'), attrs={#'class':'form-control',
                                                                            'type':'date'}),
            #'depto': forms.TextInput(attrs={'class':'dropdown-item'}),
            #'ciudad': forms.TextInput(attrs={'class':'dropdown-item'}),

        }

        def __init__(self, *args, **kwargs):
            self.asesor = kwargs.pop('asesor')
            super(Venta_Form, self).__init__(*args, **kwargs)            

        def clean_end_date(self):
            F_Documento = self.cleaned_data['fecha_documento']
            F_Nacimiento = self.cleaned_data['fecha_nacimiento']

            if F_Documento <= F_Nacimiento:
                raise forms.ValidationError("La fecha de expedición del documento debe ser mayor a la fecha de nacimiento ")
            return F_Documento

        def save(self, *args, **kwargs):
            self.instance.asesor = self.asesor
            meal = super(Venta_Form, self).save(*args, **kwargs)
            return meal